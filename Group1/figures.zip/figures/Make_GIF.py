"""
Combine the prediction_*.png figures into one animated GIF.

    python Make_GIF.py                          # uses FOLDER below
    python Make_GIF.py path/to/folder           # or give the folder on the command line
"""
import os
import re
import sys
from PIL import Image

FOLDER      = "predictions"   # where the prediction_*.png files are
PATTERN     = "prediction_"           # files starting with this and ending in .png
FRAME_MS    = 300                     # time each figure is shown (milliseconds)
OUT_NAME    = "predictions.gif"

folder = sys.argv[1] if len(sys.argv) > 1 else FOLDER
files = [f for f in os.listdir(folder) if f.startswith(PATTERN) and f.endswith(".png")]
if not files:
    sys.exit(f"No {PATTERN}*.png files found in {folder}")

# Natural sort: prediction_2 before prediction_10
files.sort(key=lambda f: [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", f)])

frames = [Image.open(os.path.join(folder, f)).convert("RGB") for f in files]
out = os.path.join(folder, OUT_NAME)
frames[0].save(out, save_all=True, append_images=frames[1:], duration=FRAME_MS, loop=0)
print(f"Saved {out} ({len(frames)} frames, {FRAME_MS} ms each)")
